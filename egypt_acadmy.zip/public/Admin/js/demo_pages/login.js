/* ------------------------------------------------------------------------------
*
*  # Login page
*
*  Demo JS code for login and registration pages
*
* ---------------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', function() {

	// Style checkboxes and radios
	$('.styled').uniform();

});
