/* ------------------------------------------------------------------------------
*
*  # Invoice template
*
*  Demo JS code for invoice_template.html page
*
* ---------------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', function() {

    // Setup CKEditor
    CKEDITOR.disableAutoInline = true;
    CKEDITOR.dtd.$removeEmpty['i'] = false;
    CKEDITOR.config.startupShowBorders = false;
    CKEDITOR.config.extraAllowedContent = 'table(*)';
    
});
