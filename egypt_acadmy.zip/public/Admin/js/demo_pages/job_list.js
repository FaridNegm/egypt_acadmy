/* ------------------------------------------------------------------------------
*
*  # Job search - list
*
*  Demo JS code for job search page kit - list view
*
* ---------------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', function() {

    // Checkboxes, radios
    $(".styled").uniform();
  
});
