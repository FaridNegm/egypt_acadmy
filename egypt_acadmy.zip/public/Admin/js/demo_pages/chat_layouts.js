/* ------------------------------------------------------------------------------
*
*  # Chat layouts
*
*  Demo JS code for chat_layouts.html page
*
* ---------------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', function() {

	// Scroll to bottom of the chat on page load. Mainly for demo
	$('.chat-list, .chat-stacked').scrollTop($(this).height());

});
