/* ------------------------------------------------------------------------------
*
*  # Learning page kit
*
*  Demo JS code for learning html page kit
*
* ---------------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', function() {

    // Checkboxes/radios (Uniform)
    // ------------------------------

    $(".styled").uniform();
    
});
