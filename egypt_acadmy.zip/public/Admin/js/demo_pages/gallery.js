/* ------------------------------------------------------------------------------
*
*  # Media gallery
*
*  Demo JS code for Gallery pages
*
* ---------------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', function() {

	// Initialize lightbox
    $('[data-popup="lightbox"]').fancybox({
        padding: 3
    });
    
});
