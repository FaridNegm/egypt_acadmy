/* ------------------------------------------------------------------------------
*
*  # Responsive tables
*
*  Demo JS code for table_responsive.html page
*
* ---------------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', function() {

	// Initialize responsive functionality
    $('.table-togglable').footable();
    
});
