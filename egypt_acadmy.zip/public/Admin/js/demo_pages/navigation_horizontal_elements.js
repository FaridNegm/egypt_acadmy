/* ------------------------------------------------------------------------------
*
*  # Horizontal navigation with elements
*
*  Demo JS code for navigation_horizontal_elements.html page
*
* ---------------------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', function() {

	// Switchery toggle inside navbar
    var switchery = document.querySelector('.navbar-switch');
    var init = new Switchery(switchery, {secondaryColor: '#000'});

});
